import os
import click
from typing import List, Dict
from .platforms.ios import iOSParser
from .platforms.android import AndroidParser
from .platforms.web import WebParser
from .platforms.flutter import FlutterParser
from .platforms.base import PlatformType, UIComponent
from .core.comparator import UIComparator
from .core.fixer import UIFixer
from .report.generator import ReportGenerator


class ConsistencyAgent:
    def __init__(self):
        self.parsers = {
            PlatformType.IOS: iOSParser(),
            PlatformType.ANDROID: AndroidParser(),
            PlatformType.WEB: WebParser(),
            PlatformType.FLUTTER: FlutterParser(),
        }
        self.comparator = UIComparator()
        self.fixer = UIFixer()
        self.reporter = ReportGenerator()

    def scan_project(self, project_paths):
        all_components = {}
        for platform, path in project_paths.items():
            if platform not in self.parsers:
                continue
            components = []
            parser = self.parsers[platform]
            for root, dirs, files in os.walk(path):
                for file in files:
                    file_path = os.path.join(root, file)
                    if not self._should_parse(file, platform):
                        continue
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            content = f.read()
                        file_components = parser.parse_file(file_path, content)
                        components.extend(file_components)
                    except Exception as e:
                        click.echo(f"Warning: Failed to parse {file_path}: {e}")
            all_components[platform] = components
            click.echo(f"✓ {platform.value}: Found {len(components)} components")
        return all_components

    def _should_parse(self, filename, platform):
        extensions = {
            PlatformType.IOS: ['.swift', '.m', '.h', '.xib', '.storyboard'],
            PlatformType.ANDROID: ['.xml', '.kt', '.java'],
            PlatformType.WEB: ['.tsx', '.jsx', '.vue', '.html', '.css', '.scss', '.less'],
            PlatformType.FLUTTER: ['.dart'],
        }
        ext = os.path.splitext(filename)[1].lower()
        return ext in extensions.get(platform, [])

    def run(self, project_paths, output_dir="./ui-consistency-report", auto_fix=False, dry_run=True):
        click.echo("🔍 开始扫描跨平台 UI 代码...")
        components = self.scan_project(project_paths)
        click.echo("\n📊 正在对比各平台一致性...")
        inconsistencies = self.comparator.compare_components(components)

        if not inconsistencies:
            click.echo("✅ 未发现不一致！所有平台 UI 完全一致。")
            return

        click.echo(f"⚠️  发现 {len(inconsistencies)} 处不一致")

        os.makedirs(output_dir, exist_ok=True)
        html_path = os.path.join(output_dir, "report.html")
        self.reporter.generate_html(inconsistencies, html_path)
        click.echo(f"📄 HTML 报告: {html_path}")

        json_path = os.path.join(output_dir, "report.json")
        self.reporter.generate_json(inconsistencies, json_path)
        click.echo(f"📄 JSON 报告: {json_path}")

        self.reporter.generate_console_report(inconsistencies)

        if auto_fix or dry_run:
            click.echo("\n🔧 修复模式...")
            fix_results = self.fixer.fix_inconsistencies(inconsistencies, dry_run=dry_run)
            click.echo(f"总计: {fix_results['total']}, 已修复: {fix_results['fixed']}, 失败: {fix_results['failed']}, 跳过: {fix_results['skipped']}")
            if dry_run:
                click.echo("💡 这是试运行模式，使用 --apply-fix 应用实际修复")


@click.command()
@click.option('--ios', '-i', help='iOS 项目路径')
@click.option('--android', '-a', help='Android 项目路径')
@click.option('--web', '-w', help='Web 项目路径')
@click.option('--flutter', '-f', help='Flutter 项目路径')
@click.option('--output', '-o', default='./ui-consistency-report', help='输出目录')
@click.option('--fix', is_flag=True, help='应用自动修复')
@click.option('--dry-run', is_flag=True, default=True, help='试运行模式')
def main(ios, android, web, flutter, output, fix, dry_run):
    """跨平台 UI 一致性检查与自动修复 Agent"""
    paths = {}
    if ios:
        paths[PlatformType.IOS] = ios
    if android:
        paths[PlatformType.ANDROID] = android
    if web:
        paths[PlatformType.WEB] = web
    if flutter:
        paths[PlatformType.FLUTTER] = flutter

    if not paths:
        click.echo("❌ 请至少指定一个平台路径")
        return

    agent = ConsistencyAgent()
    agent.run(paths, output, auto_fix=fix, dry_run=dry_run)


if __name__ == '__main__':
    main()

import json
from datetime import datetime
from typing import List, Dict
from jinja2 import Template
from ..platforms.base import Inconsistency, PlatformType


class ReportGenerator:
    def __init__(self):
        self.html_template = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>UI 一致性检查报告</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h1 { color: #1a1a1a; border-bottom: 2px solid #007AFF; padding-bottom: 10px; }
        .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin: 20px 0; }
        .stat-box { padding: 15px; border-radius: 6px; text-align: center; }
        .stat-box.error { background: #FFE5E5; color: #D32F2F; }
        .stat-box.warning { background: #FFF3E0; color: #F57C00; }
        .stat-box.info { background: #E3F2FD; color: #1976D2; }
        .stat-box.success { background: #E8F5E9; color: #388E3C; }
        .stat-number { font-size: 32px; font-weight: bold; }
        .stat-label { font-size: 14px; margin-top: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background: #007AFF; color: white; padding: 12px; text-align: left; }
        td { padding: 12px; border-bottom: 1px solid #e0e0e0; }
        tr:hover { background: #f8f9fa; }
        .severity { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
        .severity.error { background: #FFEBEE; color: #C62828; }
        .severity.warning { background: #FFF8E1; color: #FF8F00; }
        .platform-tag { display: inline-block; padding: 2px 6px; border-radius: 3px; font-size: 11px; margin-right: 4px; }
        .platform-ios { background: #E3F2FD; color: #1565C0; }
        .platform-android { background: #E8F5E9; color: #2E7D32; }
        .platform-web { background: #FFF3E0; color: #EF6C00; }
        .platform-flutter { background: #E0F7FA; color: #00838F; }
        .fix-suggestion { background: #f8f9fa; padding: 8px; border-radius: 4px; font-family: monospace; font-size: 12px; margin-top: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 跨平台 UI 一致性检查报告</h1>
        <p>生成时间: {{ timestamp }}</p>

        <div class="summary">
            <div class="stat-box error">
                <div class="stat-number">{{ stats.error }}</div>
                <div class="stat-label">错误</div>
            </div>
            <div class="stat-box warning">
                <div class="stat-number">{{ stats.warning }}</div>
                <div class="stat-label">警告</div>
            </div>
            <div class="stat-box info">
                <div class="stat-number">{{ stats.info }}</div>
                <div class="stat-label">信息</div>
            </div>
            <div class="stat-box success">
                <div class="stat-number">{{ stats.fixed }}</div>
                <div class="stat-label">已修复</div>
            </div>
        </div>

        <h2>详细结果</h2>
        <table>
            <thead>
                <tr>
                    <th>规则</th>
                    <th>严重级别</th>
                    <th>组件</th>
                    <th>涉及平台</th>
                    <th>期望值</th>
                    <th>实际值</th>
                    <th>修复建议</th>
                </tr>
            </thead>
            <tbody>
                {% for item in inconsistencies %}
                <tr>
                    <td>{{ item.rule_id }}</td>
                    <td><span class="severity {{ item.severity }}">{{ item.severity.upper() }}</span></td>
                    <td>{{ item.component_id }}</td>
                    <td>
                        {% for platform in item.platforms %}
                        <span class="platform-tag platform-{{ platform.value }}">{{ platform.value }}</span>
                        {% endfor %}
                    </td>
                    <td>{{ item.expected_value }}</td>
                    <td>
                        {% for platform, value in item.actual_values.items() %}
                        <div>{{ platform.value }}: {{ value }}</div>
                        {% endfor %}
                    </td>
                    <td>
                        {% if item.suggested_fix %}
                        <div class="fix-suggestion">{{ item.suggested_fix }}</div>
                        {% else %}
                        -
                        {% endif %}
                    </td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
</body>
</html>
        """

    def generate_html(self, inconsistencies, output_path):
        stats = {
            "error": sum(1 for i in inconsistencies if i.severity == "error"),
            "warning": sum(1 for i in inconsistencies if i.severity == "warning"),
            "info": sum(1 for i in inconsistencies if i.severity == "info"),
            "fixed": 0
        }

        template = Template(self.html_template)
        html = template.render(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            stats=stats,
            inconsistencies=inconsistencies
        )

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)

        return output_path

    def generate_json(self, inconsistencies, output_path):
        data = {
            "timestamp": datetime.now().isoformat(),
            "summary": {
                "total": len(inconsistencies),
                "error": sum(1 for i in inconsistencies if i.severity == "error"),
                "warning": sum(1 for i in inconsistencies if i.severity == "warning"),
                "info": sum(1 for i in inconsistencies if i.severity == "info")
            },
            "inconsistencies": [
                {
                    "rule_id": i.rule_id,
                    "severity": i.severity,
                    "message": i.message,
                    "component_id": i.component_id,
                    "platforms": [p.value for p in i.platforms],
                    "expected_value": str(i.expected_value),
                    "actual_values": {p.value: str(v) for p, v in i.actual_values.items()},
                    "file_paths": {p.value: v for p, v in i.file_paths.items()},
                    "line_numbers": {p.value: v for p, v in i.line_numbers.items()},
                    "auto_fixable": i.auto_fixable,
                    "suggested_fix": i.suggested_fix
                }
                for i in inconsistencies
            ]
        }

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        return output_path

    def generate_console_report(self, inconsistencies):
        from rich.console import Console
        from rich.table import Table
        from rich import box

        console = Console()

        table = Table(
            title="🔍 跨平台 UI 一致性检查结果",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan"
        )

        table.add_column("规则", style="dim", width=20)
        table.add_column("级别", width=8)
        table.add_column("组件", width=20)
        table.add_column("平台", width=15)
        table.add_column("问题描述", width=40)

        for inc in inconsistencies:
            severity_color = {
                "error": "red",
                "warning": "yellow",
                "info": "blue"
            }.get(inc.severity, "white")

            platforms_str = ", ".join([p.value for p in inc.platforms])

            table.add_row(
                inc.rule_id,
                f"[{severity_color}]{inc.severity}[/{severity_color}]",
                inc.component_id,
                platforms_str,
                inc.message
            )

        console.print(table)
        return str(table)

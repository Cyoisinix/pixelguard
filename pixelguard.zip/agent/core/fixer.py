from typing import List, Dict
from ..platforms.base import Inconsistency, PlatformType
from ..platforms.ios import iOSFixer
from ..platforms.android import AndroidFixer
from ..platforms.web import WebFixer
from ..platforms.flutter import FlutterFixer


class UIFixer:
    def __init__(self):
        self.fixers = {
            PlatformType.IOS: iOSFixer(),
            PlatformType.ANDROID: AndroidFixer(),
            PlatformType.WEB: WebFixer(),
            PlatformType.FLUTTER: FlutterFixer(),
        }

    def fix_inconsistencies(self, inconsistencies, dry_run=True):
        results = {
            "total": len(inconsistencies),
            "fixed": 0,
            "failed": 0,
            "skipped": 0,
            "details": []
        }

        for inconsistency in inconsistencies:
            if not inconsistency.auto_fixable:
                results["skipped"] += 1
                results["details"].append({
                    "rule": inconsistency.rule_id,
                    "status": "skipped",
                    "reason": "Not auto-fixable"
                })
                continue

            for platform in inconsistency.platforms:
                if platform not in self.fixers:
                    continue

                fixer = self.fixers[platform]
                file_path = inconsistency.file_paths.get(platform)
                line_number = inconsistency.line_numbers.get(platform)

                if not file_path:
                    continue

                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        lines = f.readlines()

                    if line_number > len(lines):
                        continue

                    original_line = lines[line_number - 1].rstrip('\n')
                    prop_name = self._get_property_name(inconsistency.rule_id)
                    fix_code = fixer.generate_fix(None, prop_name, inconsistency.expected_value)

                    if dry_run:
                        results["details"].append({
                            "rule": inconsistency.rule_id,
                            "status": "dry_run",
                            "platform": platform.value,
                            "file": file_path,
                            "line": line_number,
                            "original": original_line,
                            "suggested": fix_code
                        })
                    else:
                        new_line = original_line
                        success = fixer.apply_fix(file_path, original_line, new_line)
                        if success:
                            results["fixed"] += 1
                            results["details"].append({
                                "rule": inconsistency.rule_id,
                                "status": "fixed",
                                "platform": platform.value,
                                "file": file_path
                            })
                        else:
                            results["failed"] += 1

                except Exception as e:
                    results["failed"] += 1
                    results["details"].append({
                        "rule": inconsistency.rule_id,
                        "status": "error",
                        "error": str(e)
                    })

        return results

    def _get_property_name(self, rule_id):
        mapping = {
            "COLOR_CONSISTENCY": "color",
            "FONT_SIZE_CONSISTENCY": "font_size",
            "DIMENSION_CONSISTENCY": "dimension"
        }
        return mapping.get(rule_id, "unknown")

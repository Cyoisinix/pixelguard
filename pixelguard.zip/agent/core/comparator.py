from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from ..platforms.base import UIComponent, UIProperty, Inconsistency, PlatformType


@dataclass
class ComparisonRule:
    rule_id: str
    name: str
    description: str
    property_name: str
    tolerance: float = 0.0
    platforms: List[PlatformType] = field(default_factory=list)
    severity: str = "error"


class UIComparator:
    def __init__(self):
        self.rules: List[ComparisonRule] = []
        self._init_default_rules()

    def _init_default_rules(self):
        self.rules = [
            ComparisonRule(
                rule_id="COLOR_CONSISTENCY",
                name="Color Consistency",
                description="相同组件在不同平台的颜色应一致",
                property_name="color",
                platforms=[PlatformType.IOS, PlatformType.ANDROID, PlatformType.WEB, PlatformType.FLUTTER],
                severity="error"
            ),
            ComparisonRule(
                rule_id="FONT_SIZE_CONSISTENCY",
                name="Font Size Consistency",
                description="相同组件在不同平台的字体大小应一致",
                property_name="font_size",
                tolerance=0.5,
                platforms=[PlatformType.IOS, PlatformType.ANDROID, PlatformType.WEB, PlatformType.FLUTTER],
                severity="error"
            ),
            ComparisonRule(
                rule_id="DIMENSION_CONSISTENCY",
                name="Dimension Consistency",
                description="相同组件在不同平台的尺寸应一致",
                property_name="dimension",
                tolerance=1.0,
                platforms=[PlatformType.IOS, PlatformType.ANDROID, PlatformType.WEB, PlatformType.FLUTTER],
                severity="warning"
            )
        ]

    def compare_components(self, components_by_platform):
        inconsistencies = []
        components_by_type = {}
        for platform, components in components_by_platform.items():
            for comp in components:
                comp_type = comp.component_type
                if comp_type not in components_by_type:
                    components_by_type[comp_type] = {}
                if platform not in components_by_type[comp_type]:
                    components_by_type[comp_type][platform] = []
                components_by_type[comp_type][platform].append(comp)

        for comp_type, platform_components in components_by_type.items():
            for rule in self.rules:
                relevant_platforms = [p for p in rule.platforms if p in platform_components]
                if len(relevant_platforms) < 2:
                    continue
                property_values = {}
                property_locations = {}
                for platform in relevant_platforms:
                    property_values[platform] = []
                    property_locations[platform] = []
                    for comp in platform_components[platform]:
                        prop = comp.get_property(rule.property_name)
                        if prop:
                            property_values[platform].append(prop.value)
                            property_locations[platform].append((prop.file_path, prop.line_number, prop.context))

                if property_values:
                    inconsistency = self._check_property_consistency(comp_type, rule, property_values, property_locations)
                    if inconsistency:
                        inconsistencies.append(inconsistency)

        return inconsistencies

    def _check_property_consistency(self, comp_type, rule, property_values, property_locations):
        all_values = []
        for platform, values in property_values.items():
            all_values.extend(values)
        if not all_values:
            return None

        if rule.property_name in ['font_size', 'dimension']:
            numeric_values = [v for v in all_values if isinstance(v, (int, float))]
            if not numeric_values:
                return None
            mean_value = sum(numeric_values) / len(numeric_values)
            deviant_platforms = []
            actual_values = {}
            file_paths = {}
            line_numbers = {}
            for platform, values in property_values.items():
                for i, val in enumerate(values):
                    if isinstance(val, (int, float)):
                        if abs(val - mean_value) > rule.tolerance:
                            deviant_platforms.append(platform)
                            actual_values[platform] = val
                            file_paths[platform] = property_locations[platform][i][0]
                            line_numbers[platform] = property_locations[platform][i][1]
                            break
            if deviant_platforms:
                return Inconsistency(
                    severity=rule.severity,
                    rule_id=rule.rule_id,
                    message=f"{comp_type} 的 {rule.property_name} 不一致: 期望 {mean_value:.1f}, 实际 {actual_values}",
                    component_id=f"{comp_type}_group",
                    platforms=deviant_platforms,
                    expected_value=mean_value,
                    actual_values=actual_values,
                    file_paths=file_paths,
                    line_numbers=line_numbers,
                    auto_fixable=True,
                    suggested_fix=f"将 {rule.property_name} 统一为 {mean_value:.1f}"
                )

        elif rule.property_name == 'color':
            unique_values = set(str(v) for v in all_values)
            if len(unique_values) > 1:
                from collections import Counter
                value_counts = Counter(str(v) for v in all_values)
                expected = value_counts.most_common(1)[0][0]
                deviant_platforms = []
                actual_values = {}
                file_paths = {}
                line_numbers = {}
                for platform, values in property_values.items():
                    for i, val in enumerate(values):
                        if str(val) != expected:
                            deviant_platforms.append(platform)
                            actual_values[platform] = val
                            file_paths[platform] = property_locations[platform][i][0]
                            line_numbers[platform] = property_locations[platform][i][1]
                            break
                if deviant_platforms:
                    return Inconsistency(
                        severity=rule.severity,
                        rule_id=rule.rule_id,
                        message=f"{comp_type} 的颜色不一致: 期望 {expected}, 实际 {actual_values}",
                        component_id=f"{comp_type}_group",
                        platforms=deviant_platforms,
                        expected_value=expected,
                        actual_values=actual_values,
                        file_paths=file_paths,
                        line_numbers=line_numbers,
                        auto_fixable=True,
                        suggested_fix=f"将颜色统一为 {expected}"
                    )
        return None

    def add_custom_rule(self, rule):
        self.rules.append(rule)

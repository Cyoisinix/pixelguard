import re
import xml.etree.ElementTree as ET
from typing import List, Optional, Any
from .base import PlatformParser, PlatformFixer, PlatformType, UIComponent, UIProperty


class AndroidParser(PlatformParser):
    def __init__(self):
        super().__init__(PlatformType.ANDROID)

    def parse_file(self, file_path: str, content: str) -> List[UIComponent]:
        components = []

        if file_path.endswith('.xml'):
            components.extend(self._parse_xml(file_path, content))
        elif file_path.endswith('.kt') or file_path.endswith('.java'):
            components.extend(self._parse_compose(file_path, content))

        return components

    def _parse_xml(self, file_path: str, content: str) -> List[UIComponent]:
        components = []
        try:
            root = ET.fromstring(content)
            self._traverse_xml(root, file_path, components, 1)
        except ET.ParseError:
            lines = content.split('\n')
            for i, line in enumerate(lines, 1):
                if '<' in line and '>' in line:
                    tag_match = re.search(r'<(\w+)', line)
                    if tag_match:
                        comp = UIComponent(
                            component_id=f"{file_path}:{i}",
                            component_type=tag_match.group(1),
                            platform=PlatformType.ANDROID,
                            file_path=file_path,
                            line_start=i,
                            line_end=i
                        )
                        for attr in ['android:textColor', 'android:background', 
                                   'android:textSize', 'android:layout_width',
                                   'android:layout_height', 'android:padding']:
                            val = self._extract_attr(line, attr)
                            if val:
                                prop_name = attr.split(':')[-1]
                                if 'Color' in attr or 'background' in attr:
                                    parsed = self.parse_color(val)
                                    if parsed:
                                        prop_name = 'color'
                                        val = parsed
                                    else:
                                        continue
                                elif 'Size' in attr:
                                    parsed = self.parse_dimension(val)
                                    if parsed:
                                        val = parsed
                                    else:
                                        continue
                                elif 'width' in attr or 'height' in attr:
                                    parsed = self.parse_dimension(val)
                                    if parsed:
                                        val = parsed

                                comp.add_property(UIProperty(
                                    name=prop_name,
                                    value=val,
                                    line_number=i,
                                    file_path=file_path,
                                    context=line.strip()
                                ))
                        components.append(comp)
        return components

    def _traverse_xml(self, element, file_path, components, line_num):
        comp = UIComponent(
            component_id=f"{file_path}:{line_num}",
            component_type=element.tag.split('.')[-1],
            platform=PlatformType.ANDROID,
            file_path=file_path,
            line_start=line_num,
            line_end=line_num
        )

        for attr, val in element.attrib.items():
            attr_name = attr.split(':')[-1]
            if 'color' in attr.lower() or attr.endswith('Color'):
                parsed = self.parse_color(val)
                if parsed:
                    comp.add_property(UIProperty(
                        name='color', value=parsed, line_number=line_num,
                        file_path=file_path, context=f"{attr}={val}"
                    ))
            elif 'size' in attr.lower() or attr in ['textSize']:
                parsed = self.parse_dimension(val)
                if parsed:
                    comp.add_property(UIProperty(
                        name='font_size', value=parsed, line_number=line_num,
                        file_path=file_path, context=f"{attr}={val}"
                    ))
            elif attr in ['layout_width', 'layout_height', 'padding']:
                parsed = self.parse_dimension(val)
                if parsed:
                    comp.add_property(UIProperty(
                        name='dimension', value=parsed, line_number=line_num,
                        file_path=file_path, context=f"{attr}={val}"
                    ))

        components.append(comp)

        for child in element:
            self._traverse_xml(child, file_path, components, line_num + 1)
            child_comp = components[-1]
            child_comp.parent = comp
            comp.children.append(child_comp)

    def _extract_attr(self, line: str, attr: str) -> Optional[str]:
        pattern = rf'{attr}\s*=\s*"([^"]+)"'
        match = re.search(pattern, line)
        return match.group(1) if match else None

    def _parse_compose(self, file_path: str, content: str) -> List[UIComponent]:
        components = []
        lines = content.split('\n')

        for i, line in enumerate(lines, 1):
            if re.search(r'^\s*(Text|Button|Column|Row|Box|Card|Surface)\s*\(', line):
                comp = UIComponent(
                    component_id=f"{file_path}:{i}",
                    component_type=re.search(r'(Text|Button|Column|Row|Box|Card|Surface)', line).group(1),
                    platform=PlatformType.ANDROID,
                    file_path=file_path,
                    line_start=i,
                    line_end=i
                )

                color_match = re.search(r'color\s*=\s*Color\(([^)]+)\)', line)
                if color_match:
                    parsed = self.parse_color(color_match.group(1))
                    if parsed:
                        comp.add_property(UIProperty(
                            name='color', value=parsed, line_number=i,
                            file_path=file_path, context=line.strip()
                        ))

                font_match = re.search(r'fontSize\s*=\s*([\d.]+)\.sp', line)
                if font_match:
                    comp.add_property(UIProperty(
                        name='font_size', value=float(font_match.group(1)),
                        line_number=i, file_path=file_path, context=line.strip()
                    ))

                components.append(comp)

        return components

    def parse_color(self, value: str) -> Optional[str]:
        named_colors = {
            'BLACK': '#000000FF', 'WHITE': '#FFFFFFFF', 'RED': '#FF0000FF',
            'GREEN': '#00FF00FF', 'BLUE': '#0000FFFF', 'TRANSPARENT': '#00000000',
        }
        clean = value.strip().upper()
        if clean in named_colors:
            return named_colors[clean]

        if value.startswith('@color/') or value.startswith('@android:color/'):
            return None

        return self.extract_hex_color(value)

    def parse_dimension(self, value: str) -> Optional[float]:
        match = re.match(r'^(\d+(?:\.\d+)?)\s*(dp|sp|px|pt)?$', value.strip())
        if match:
            return float(match.group(1))

        if value in ['match_parent', 'wrap_content', 'fill_parent']:
            return None

        return self.normalize_dimension(value)


class AndroidFixer(PlatformFixer):
    def __init__(self):
        super().__init__(PlatformType.ANDROID)

    def generate_fix(self, component: UIComponent, property_name: str, 
                    target_value: Any) -> str:
        if property_name == "color":
            if component.file_path.endswith('.xml'):
                return f'android:textColor="{target_value}"'
            else:
                return f'color = Color({target_value})'
        elif property_name == "font_size":
            if component.file_path.endswith('.xml'):
                return f'android:textSize="{target_value}sp"'
            else:
                return f'fontSize = {target_value}.sp'
        return ""

    def apply_fix(self, file_path: str, original: str, replacement: str) -> bool:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            if original not in content:
                return False

            content = content.replace(original, replacement, 1)

            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            print(f"Fix failed for {file_path}: {e}")
            return False

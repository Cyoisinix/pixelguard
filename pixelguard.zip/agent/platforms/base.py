from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum
import re


class PlatformType(Enum):
    IOS = "ios"
    ANDROID = "android"
    WEB = "web"
    FLUTTER = "flutter"


@dataclass
class UIProperty:
    name: str
    value: Any
    line_number: int
    file_path: str
    context: str = ""


@dataclass
class UIComponent:
    component_id: str
    component_type: str
    platform: PlatformType
    file_path: str
    line_start: int
    line_end: int
    properties: Dict[str, UIProperty] = field(default_factory=dict)
    children: List['UIComponent'] = field(default_factory=list)
    parent: Optional['UIComponent'] = None

    def get_property(self, name: str) -> Optional[UIProperty]:
        return self.properties.get(name)

    def add_property(self, prop: UIProperty):
        self.properties[prop.name] = prop


@dataclass
class Inconsistency:
    severity: str
    rule_id: str
    message: str
    component_id: str
    platforms: List[PlatformType]
    expected_value: Any
    actual_values: Dict[PlatformType, Any]
    file_paths: Dict[PlatformType, str]
    line_numbers: Dict[PlatformType, int]
    auto_fixable: bool = False
    suggested_fix: Optional[str] = None


class PlatformParser(ABC):
    def __init__(self, platform_type: PlatformType):
        self.platform_type = platform_type
        self.components: List[UIComponent] = []

    @abstractmethod
    def parse_file(self, file_path: str, content: str) -> List[UIComponent]:
        pass

    @abstractmethod
    def parse_color(self, value: str) -> Optional[str]:
        pass

    @abstractmethod
    def parse_dimension(self, value: str) -> Optional[float]:
        pass

    def extract_hex_color(self, value: str) -> Optional[str]:
        patterns = [
            r'#([0-9A-Fa-f]{8})',
            r'#([0-9A-Fa-f]{6})',
            r'#([0-9A-Fa-f]{3})',
            r'0x([0-9A-Fa-f]{8})',
            r'Color\((?:0x)?([0-9A-Fa-f]{6,8})\)',
        ]
        for pattern in patterns:
            match = re.search(pattern, value)
            if match:
                hex_val = match.group(1)
                if len(hex_val) == 3:
                    hex_val = ''.join(c*2 for c in hex_val)
                if len(hex_val) == 6:
                    hex_val += 'FF'
                return f'#{hex_val.upper()}'
        return None

    def normalize_dimension(self, value: str) -> Optional[float]:
        match = re.match(r'^(\d+(?:\.\d+)?)\s*(px|dp|pt|sp|rem|em|%)?$', value.strip())
        if match:
            return float(match.group(1))
        return None


class PlatformFixer(ABC):
    def __init__(self, platform_type: PlatformType):
        self.platform_type = platform_type

    @abstractmethod
    def generate_fix(self, component: UIComponent, property_name: str, 
                    target_value: Any) -> str:
        pass

    @abstractmethod
    def apply_fix(self, file_path: str, original: str, replacement: str) -> bool:
        pass

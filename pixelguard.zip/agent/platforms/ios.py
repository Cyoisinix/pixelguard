import re
from typing import List, Optional, Any
from .base import PlatformParser, PlatformFixer, PlatformType, UIComponent, UIProperty


class iOSParser(PlatformParser):
    def __init__(self):
        super().__init__(PlatformType.IOS)
        self.color_patterns = [
            r'Color\((?:\.init)?\s*\(\s*red:\s*([\d.]+)\s*,\s*green:\s*([\d.]+)\s*,\s*blue:\s*([\d.]+)',
            r'Color\("([^"]+)"\)',
            r'\.foregroundColor\(\s*([^)]+)\s*\)',
            r'\.background\(\s*([^)]+)\s*\)',
            r'UIColor\((?:\.init)?\s*\(\s*red:\s*([\d.]+)\s*,\s*green:\s*([\d.]+)\s*,\s*blue:\s*([\d.]+)',
        ]
        self.dimension_patterns = [
            r'\.frame\([^)]*width:\s*([\d.]+)',
            r'\.frame\([^)]*height:\s*([\d.]+)',
            r'\.padding\(\s*([\d.]+)',
            r'\.cornerRadius\(\s*([\d.]+)',
            r'\.font\(\.system\(size:\s*([\d.]+)',
        ]

    def parse_file(self, file_path: str, content: str) -> List[UIComponent]:
        components = []
        lines = content.split('\n')
        stack = []

        for i, line in enumerate(lines, 1):
            indent = len(line) - len(line.lstrip())

            component_match = re.match(r'\s*(?:struct\s+(\w+)|var\s+body|(\w+)\s*\{)', line)
            if component_match:
                comp_type = component_match.group(1) or component_match.group(2) or "View"
                comp_id = f"{file_path}:{i}"

                component = UIComponent(
                    component_id=comp_id,
                    component_type=comp_type,
                    platform=PlatformType.IOS,
                    file_path=file_path,
                    line_start=i,
                    line_end=i,
                    properties={}
                )

                for pattern in self.color_patterns:
                    for match in re.finditer(pattern, line):
                        color_val = match.group(1) if match.lastindex == 1 else match.group(0)
                        hex_color = self.parse_color(color_val)
                        if hex_color:
                            prop = UIProperty(
                                name="color",
                                value=hex_color,
                                line_number=i,
                                file_path=file_path,
                                context=line.strip()
                            )
                            component.add_property(prop)

                for pattern in self.dimension_patterns:
                    for match in re.finditer(pattern, line):
                        dim_val = match.group(1)
                        normalized = self.parse_dimension(dim_val)
                        if normalized:
                            prop_name = "font_size" if "font" in pattern else "dimension"
                            prop = UIProperty(
                                name=prop_name,
                                value=normalized,
                                line_number=i,
                                file_path=file_path,
                                context=line.strip()
                            )
                            component.add_property(prop)

                if stack:
                    component.parent = stack[-1]
                    stack[-1].children.append(component)

                components.append(component)
                stack.append(component)

            if '}' in line and stack:
                if indent <= (len(lines[stack[-1].line_start-1]) - len(lines[stack[-1].line_start-1].lstrip())):
                    stack[-1].line_end = i
                    stack.pop()

        return components

    def parse_color(self, value: str) -> Optional[str]:
        named_colors = {
            'red': '#FF0000FF', 'green': '#00FF00FF', 'blue': '#0000FFFF',
            'black': '#000000FF', 'white': '#FFFFFFFF', 'clear': '#00000000',
        }
        clean = value.strip().strip('"').strip("'")
        if clean in named_colors:
            return named_colors[clean]

        if clean.startswith('.'):
            return None

        return self.extract_hex_color(value)

    def parse_dimension(self, value: str) -> Optional[float]:
        return self.normalize_dimension(value)


class iOSFixer(PlatformFixer):
    def __init__(self):
        super().__init__(PlatformType.IOS)

    def generate_fix(self, component: UIComponent, property_name: str, 
                    target_value: Any) -> str:
        if property_name == "color":
            return f'.foregroundColor(Color("{target_value}"))'
        elif property_name == "font_size":
            return f'.font(.system(size: {target_value}))'
        elif property_name == "dimension":
            return f'.frame(width: {target_value}, height: {target_value})'
        return ""

    def apply_fix(self, file_path: str, original: str, replacement: str) -> bool:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            if original not in content:
                return False

            content = content.replace(original, replacement, 1)

            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            print(f"Fix failed for {file_path}: {e}")
            return False

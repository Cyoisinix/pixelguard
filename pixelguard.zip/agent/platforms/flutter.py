import re
from typing import List, Optional, Any
from .base import PlatformParser, PlatformFixer, PlatformType, UIComponent, UIProperty


class FlutterParser(PlatformParser):
    def __init__(self):
        super().__init__(PlatformType.FLUTTER)

    def parse_file(self, file_path, content):
        components = []
        lines = content.split('\n')
        stack = []
        for i, line in enumerate(lines, 1):
            widget_match = re.match(r'\s*(\w+)\s*\(', line)
            if widget_match and self._is_widget(widget_match.group(1)):
                widget_name = widget_match.group(1)
                comp_id = f"{file_path}:{i}"
                comp = UIComponent(component_id=comp_id, component_type=widget_name, platform=PlatformType.FLUTTER, file_path=file_path, line_start=i, line_end=i)
                color_patterns = [
                    r'color:\s*Color\((?:0x)?([0-9A-Fa-f]{6,8})\)',
                    r'color:\s*Colors\.(\w+)',
                    r'style:\s*TextStyle\([^)]*color:\s*Color\((?:0x)?([0-9A-Fa-f]{6,8})\)',
                ]
                for pattern in color_patterns:
                    match = re.search(pattern, line)
                    if match:
                        if match.lastindex == 1:
                            parsed = self.parse_color(f"0x{match.group(1)}")
                        else:
                            parsed = self.parse_color(f"Colors.{match.group(1)}")
                        if parsed:
                            comp.add_property(UIProperty(name='color', value=parsed, line_number=i, file_path=file_path, context=line.strip()))
                font_match = re.search(r'fontSize:\s*([\d.]+)', line)
                if font_match:
                    comp.add_property(UIProperty(name='font_size', value=float(font_match.group(1)), line_number=i, file_path=file_path, context=line.strip()))
                size_patterns = [
                    r'width:\s*([\d.]+)',
                    r'height:\s*([\d.]+)',
                    r'sizedBox\s*\(\s*width:\s*([\d.]+)',
                    r'sizedBox\s*\(\s*height:\s*([\d.]+)',
                ]
                for pattern in size_patterns:
                    match = re.search(pattern, line, re.IGNORECASE)
                    if match:
                        comp.add_property(UIProperty(name='dimension', value=float(match.group(1)), line_number=i, file_path=file_path, context=line.strip()))
                if stack:
                    comp.parent = stack[-1]
                    stack[-1].children.append(comp)
                components.append(comp)
                stack.append(comp)
            if ')' in line or '}' in line:
                if stack and (line.strip().endswith('),') or line.strip().endswith(')') or line.strip() == '}'):
                    stack[-1].line_end = i
                    stack.pop()
        return components

    def _is_widget(self, name):
        widgets = {'Container', 'Text', 'Column', 'Row', 'Stack', 'Scaffold', 'AppBar',
                   'ElevatedButton', 'TextButton', 'OutlinedButton', 'Card', 'ListView',
                   'Padding', 'Center', 'Align', 'Expanded', 'Flexible', 'SizedBox',
                   'DecoratedBox', 'Material', 'InkWell', 'GestureDetector'}
        return name in widgets or name.endswith('Widget')

    def parse_color(self, value):
        flutter_colors = {
            'Colors.red': '#FF0000FF', 'Colors.green': '#00FF00FF',
            'Colors.blue': '#0000FFFF', 'Colors.black': '#000000FF',
            'Colors.white': '#FFFFFFFF', 'Colors.transparent': '#00000000',
        }
        clean = value.strip()
        if clean in flutter_colors:
            return flutter_colors[clean]
        match = re.match(r'0x([0-9A-Fa-f]{8})', clean)
        if match:
            hex_val = match.group(1)
            a = hex_val[0:2]
            r = hex_val[2:4]
            g = hex_val[4:6]
            b = hex_val[6:8]
            return f'#{r}{g}{b}{a}'.upper()
        match = re.match(r'0x([0-9A-Fa-f]{6})', clean)
        if match:
            return f'#{match.group(1).upper()}FF'
        return self.extract_hex_color(value)

    def parse_dimension(self, value):
        return self.normalize_dimension(value)


class FlutterFixer(PlatformFixer):
    def __init__(self):
        super().__init__(PlatformType.FLUTTER)

    def generate_fix(self, component, property_name, target_value):
        if property_name == "color":
            return f'color: Color(0x{target_value.lstrip("#")})'
        elif property_name == "font_size":
            return f'fontSize: {target_value}'
        elif property_name == "dimension":
            return f'width: {target_value}, height: {target_value}'
        return ""

    def apply_fix(self, file_path, original, replacement):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            if original not in content:
                return False
            content = content.replace(original, replacement, 1)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            print(f"Fix failed for {file_path}: {e}")
            return False

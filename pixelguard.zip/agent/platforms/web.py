import re
from typing import List, Optional, Any
from .base import PlatformParser, PlatformFixer, PlatformType, UIComponent, UIProperty


class WebParser(PlatformParser):
    def __init__(self):
        super().__init__(PlatformType.WEB)
        self.css_properties = [
            'color', 'background-color', 'font-size', 'width', 'height',
            'padding', 'margin', 'border-radius', 'font-family'
        ]

    def parse_file(self, file_path: str, content: str) -> List[UIComponent]:
        components = []
        if file_path.endswith(('.css', '.scss', '.less')):
            components.extend(self._parse_css(file_path, content))
        elif file_path.endswith(('.tsx', '.jsx', '.vue', '.html')):
            components.extend(self._parse_component(file_path, content))
        return components

    def _parse_css(self, file_path, content):
        components = []
        pattern = r'([.#][^{]+)\{([^}]+)\}'
        matches = re.finditer(pattern, content, re.DOTALL)
        for match in matches:
            selector = match.group(1).strip()
            declarations = match.group(2)
            line_num = content[:match.start()].count('\n') + 1
            comp = UIComponent(
                component_id=f"{file_path}:{selector}",
                component_type="css_rule",
                platform=PlatformType.WEB,
                file_path=file_path,
                line_start=line_num,
                line_end=line_num + declarations.count('\n')
            )
            for prop in self.css_properties:
                val = self._extract_css_prop(declarations, prop)
                if val:
                    if 'color' in prop:
                        parsed = self.parse_color(val)
                        if parsed:
                            comp.add_property(UIProperty(name='color', value=parsed, line_number=line_num, file_path=file_path, context=f"{prop}: {val}"))
                    elif 'size' in prop:
                        parsed = self.parse_dimension(val)
                        if parsed:
                            comp.add_property(UIProperty(name='font_size', value=parsed, line_number=line_num, file_path=file_path, context=f"{prop}: {val}"))
                    elif prop in ['width', 'height', 'padding', 'margin', 'border-radius']:
                        parsed = self.parse_dimension(val)
                        if parsed:
                            comp.add_property(UIProperty(name='dimension', value=parsed, line_number=line_num, file_path=file_path, context=f"{prop}: {val}"))
            components.append(comp)
        return components

    def _parse_component(self, file_path, content):
        components = []
        lines = content.split('\n')
        for i, line in enumerate(lines, 1):
            style_match = re.search(r'style\s*=\s*\{?\s*\{([^}]+)\}', line)
            if style_match:
                style_content = style_match.group(1)
                comp = UIComponent(component_id=f"{file_path}:{i}", component_type="inline_style", platform=PlatformType.WEB, file_path=file_path, line_start=i, line_end=i)
                color_match = re.search(r'color:\s*[\'"]?([^,\}]+)[\'"]?', style_content)
                if color_match:
                    parsed = self.parse_color(color_match.group(1))
                    if parsed:
                        comp.add_property(UIProperty(name='color', value=parsed, line_number=i, file_path=file_path, context=line.strip()))
                font_match = re.search(r'fontSize:\s*[\'"]?([^,\}]+)[\'"]?', style_content)
                if font_match:
                    parsed = self.parse_dimension(font_match.group(1))
                    if parsed:
                        comp.add_property(UIProperty(name='font_size', value=parsed, line_number=i, file_path=file_path, context=line.strip()))
                components.append(comp)
            tailwind_match = re.search(r'className\s*=\s*"([^"]+)"', line)
            if tailwind_match:
                classes = tailwind_match.group(1).split()
                comp = UIComponent(component_id=f"{file_path}:{i}", component_type="tailwind", platform=PlatformType.WEB, file_path=file_path, line_start=i, line_end=i)
                if comp.properties:
                    components.append(comp)
        return components

    def _extract_css_prop(self, declarations, prop):
        pattern = rf'{prop}\s*:\s*([^;]+)'
        match = re.search(pattern, declarations)
        return match.group(1).strip() if match else None

    def parse_color(self, value):
        css_colors = {
            'black': '#000000FF', 'white': '#FFFFFFFF', 'red': '#FF0000FF',
            'blue': '#0000FFFF', 'green': '#008000FF', 'transparent': '#00000000',
        }
        clean = value.strip().lower()
        if clean in css_colors:
            return css_colors[clean]
        rgb_match = re.match(r'rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)', clean)
        if rgb_match:
            r, g, b = int(rgb_match.group(1)), int(rgb_match.group(2)), int(rgb_match.group(3))
            a = int(float(rgb_match.group(4)) * 255) if rgb_match.group(4) else 255
            return f'#{r:02X}{g:02X}{b:02X}{a:02X}'
        if clean.startswith('var('):
            return None
        return self.extract_hex_color(value)

    def parse_dimension(self, value):
        rem_match = re.match(r'([\d.]+)rem', value.strip())
        if rem_match:
            return float(rem_match.group(1)) * 16
        em_match = re.match(r'([\d.]+)em', value.strip())
        if em_match:
            return float(em_match.group(1)) * 16
        return self.normalize_dimension(value)


class WebFixer(PlatformFixer):
    def __init__(self):
        super().__init__(PlatformType.WEB)

    def generate_fix(self, component, property_name, target_value):
        if property_name == "color":
            return f'color: {target_value}'
        elif property_name == "font_size":
            return f'font-size: {target_value}px'
        elif property_name == "dimension":
            return f'width: {target_value}px; height: {target_value}px'
        return ""

    def apply_fix(self, file_path, original, replacement):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            if original not in content:
                return False
            content = content.replace(original, replacement, 1)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            print(f"Fix failed for {file_path}: {e}")
            return False

# PixelGuard 🔍

跨平台 UI 一致性检查与自动修复 Agent。

## 支持平台

- iOS (SwiftUI / UIKit)
- Android (XML / Jetpack Compose)
- Web (React / Vue / CSS)
- Flutter

## 快速开始

```bash
pip install -r requirements.txt
python main.py --ios ./ios --android ./android --web ./web
```

## 功能特性

- 多平台 UI 代码解析
- 设计令牌一致性检查
- 自动修复建议
- HTML/JSON 报告生成

## 许可证

MIT
